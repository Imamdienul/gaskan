
$(document).ready(function () {
        $('#closemodal').click(function () {
            $('#modal_Detail').modal('hide');
        });

});
    
